Rest mit JPA , Spring Boot und Test für Controller mit Mock
basiert auf  sk.train.x12_07_JPA_Rest_Boot_Test_Solution