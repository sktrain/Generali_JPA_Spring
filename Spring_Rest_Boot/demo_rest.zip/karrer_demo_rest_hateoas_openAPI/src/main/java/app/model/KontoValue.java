package app.model;

public class KontoValue {
	
	private int kontonummer;
	private int saldo;
	public KontoValue(int kontonummer, int saldo) {
		super();
		this.kontonummer = kontonummer;
		this.saldo = saldo;
	}
	
	

}
