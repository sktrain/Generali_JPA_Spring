package app.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import app.model.Konto;
@RepositoryRestResource(collectionResourceRel = "people", path = "people")
public interface KontoRepository extends JpaRepository<Konto, Integer>{

}
