Beispiel:
Zeigt die Generierung der entsprechenden Tabelle anhand der Entitätsklasse zur Laufzeit.
Gesteuert durch entsprechende Einträge in der persistenc.xml.