package appl;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import ifaces.Performer;

public class Application {
	public static void main(String[] args) {
		try (final AnnotationConfigApplicationContext ctx = 
				new AnnotationConfigApplicationContext("beans")) {
			
			//todo
			
		}
	}
}
