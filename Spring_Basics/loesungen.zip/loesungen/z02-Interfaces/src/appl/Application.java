package appl;


public class Application {
	public static void main(String[] args) {
		final OrderReader reader = new CsvOrderReader("src/orders.txt");
		final Database database = new DatabaseDummy();
		final OrderPrinter printer = new SimpleOrderPrinter();
		new GroupChangeProcessorImpl(reader, database, printer).run();
	}
}
