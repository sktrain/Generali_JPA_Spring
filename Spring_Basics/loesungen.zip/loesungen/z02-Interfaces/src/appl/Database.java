package appl;


public interface Database {
	public abstract Customer findCustomer(int number);
	public abstract Product findProduct(int number);
}
