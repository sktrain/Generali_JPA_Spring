package appl;


public interface GroupChangeProcessor {
	public abstract void run();
}
