package appl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:order.properties")
public class ApplConfig {

	@Value("${filename}")
	private String filename;

	@Bean
	public Database database() {
		return new DatabaseDummy();
	}
	@Bean
	public OrderReader orderReader() {
		return new CsvOrderReader(this.filename) ;
	}
	@Bean
	public OrderPrinter orderPrinter() {
		return new SimpleOrderPrinter();
	}
	@Bean
	public GroupChangeProcessor processor() {
		return new GroupChangeProcessorImpl(this.orderReader(), this.database(), this.orderPrinter());
	}
}
