package appl;

public class SimpleOrderPrinter implements OrderPrinter {
	@Override
	public void printBegin() {
		System.out.println("Orders");
	}
	@Override
	public void printGroupBegin(Customer customer) {
		System.out.printf("   %4d %-10s\n", customer.getNumber(), customer.getName());
	}
	@Override
	public void printItem(Order order, Product product, int value) {
		System.out.printf("       %4d %-10s %4d  %4d   %5d\n", 
				order.getProductNumber(), product.getName(), order.getAmount(), product.getPrice(), value);
	}
	@Override
	public void printGroupEnd(int groupSum) {
		System.out.printf("                                    -----\n");
		System.out.printf("                                    %5d\n", groupSum);
	}
	@Override
	public void printEnd(int totalSum) {
		System.out.printf("                                    =====\n");
		System.out.printf("                                    %5d\n", totalSum);
	}
}
