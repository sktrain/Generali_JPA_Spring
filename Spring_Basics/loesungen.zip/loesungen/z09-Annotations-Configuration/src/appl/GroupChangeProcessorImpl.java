package appl;

public class GroupChangeProcessorImpl implements GroupChangeProcessor {

	private final OrderReader reader;
	private final Database database;
	private final OrderPrinter printer;

	public GroupChangeProcessorImpl(
			OrderReader reader,
			Database database,
			OrderPrinter printer) {
		this.reader = reader;
		this.database = database;
		this.printer = printer;
	}

	@Override
	public void run() {
		Order order = this.reader.read();
		this.printer.printBegin();
		int totalSum = 0;
		while (order != null) {
			int groupSum = 0;
			final int customerNumber = order.getCustomerNumber();
			final Customer customer = this.database.findCustomer(customerNumber);
			this.printer.printGroupBegin(customer);
			while (order != null && order.getCustomerNumber() == customerNumber) {
				final Product product = this.database.findProduct(order.getProductNumber());
				final int itemValue = order.getAmount() * product.getPrice();
				this.printer.printItem(order, product, itemValue);
				groupSum += itemValue;
				order = this.reader.read();
			}
			this.printer.printGroupEnd(groupSum);
			totalSum += groupSum;
		}
		this.printer.printEnd(totalSum);
		this.reader.close();
	}

}
