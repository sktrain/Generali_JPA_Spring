package appl;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class CsvOrderReader implements OrderReader {

	private BufferedReader reader;

	public CsvOrderReader(String filename) {
		try {
			this.reader = new BufferedReader(new InputStreamReader(new FileInputStream(filename)));
		}
		catch (final Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public void close() {
		if (this.reader == null)
			throw new RuntimeException("reader not open");
		try {
			this.reader.close();
		}
		catch (final Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public Order read() {
		try {
			for(String line = this.reader.readLine(); line != null; line = this.reader.readLine()) {
				line = line.trim();
				if (line.isEmpty())
					continue;
				final String[] tokens = line.split(",");
				final int customerNumber = Integer.parseInt(tokens[0].trim());
				final int productNumber = Integer.parseInt(tokens[1].trim());
				final int amount = Integer.parseInt(tokens[2].trim());
				return new Order(customerNumber, productNumber, amount);
			}
			return null;
		}
		catch(final Exception e) {
			throw new RuntimeException(e);
		}
		
	}
}
