package appl;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Application {
	public static void main(String[] args) {
		try (AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext("appl")) {
			ctx.getBean(GroupChangeProcessor.class).run();
		}
	}
}
