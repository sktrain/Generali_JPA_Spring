package appl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component("gcp")
public class GroupChangeProcessorImpl implements GroupChangeProcessor {
	
	@Autowired
	private OrderReader reader;
	
	@Autowired
	private Database database;

	@Autowired
	private OrderPrinter printer;

	@Override
	public void run() {
		Order order = this.reader.read();
		this.printer.printBegin();
		int totalSum = 0;
		while(order != null) {
			int groupSum = 0;
			final int customerNumber = order.getCustomerNumber();
			final Customer customer = this.database.findCustomer(customerNumber);
			this.printer.printGroupBegin(customer);
			while(order != null && order.getCustomerNumber() == customerNumber) {
				final Product product = this.database.findProduct(order.getProductNumber());
				final int itemValue = order.getAmount() * product.getPrice();
				this.printer.printPosition(order, product, itemValue);
				groupSum += itemValue;
				order = this.reader.read();
			}
			this.printer.printGroupEnd(groupSum);
			totalSum += groupSum;
		}
		this.printer.printEnd(totalSum);
		this.reader.close();
	}
	
}
