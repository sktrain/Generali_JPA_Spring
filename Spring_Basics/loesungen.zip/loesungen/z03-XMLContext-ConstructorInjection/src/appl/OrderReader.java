package appl;

public interface OrderReader {
	public abstract void close();
	public abstract Order read();
}
