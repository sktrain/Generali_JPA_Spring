package appl;

import processor.Database;
import processor.GroupChangeProcessor;
import processor.OrderPrinter;
import processor.OrderReader;
import processor.impl.DatabaseDummy;
import processor.impl.GroupChangeProcessorImpl;
import processor.impl.SimpleOrderPrinter;
import processor.impl.SimpleOrderReader;

public class Application {
	public static void main(String[] args) {
		OrderReader reader = new SimpleOrderReader("src/orders.txt");
		Database database = new DatabaseDummy();
		OrderPrinter printer = new SimpleOrderPrinter();
		GroupChangeProcessor p = new GroupChangeProcessorImpl(reader, database, printer);
		p.run();
	}
}
