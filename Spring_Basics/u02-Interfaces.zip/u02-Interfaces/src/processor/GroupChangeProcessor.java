package processor;


public interface GroupChangeProcessor {
	public abstract void run();
}
