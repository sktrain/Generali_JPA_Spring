package processor;

import domain.Order;

public interface OrderReader {
	public abstract void close();
	public abstract Order read();
}
