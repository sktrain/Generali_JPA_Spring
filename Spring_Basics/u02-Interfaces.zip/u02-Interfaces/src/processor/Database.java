package processor;

import domain.Customer;
import domain.Product;

public interface Database {
	public abstract Customer findCustomer(int number);
	public abstract Product findProduct(int number);
}
