package beans;

import org.springframework.beans.factory.annotation.Autowired;

import ifaces.DiffService;
import ifaces.MathService;
import ifaces.SumService;
import jn.util.Log;

public class MathServiceImpl implements MathService {
	SumService sumService;
	private final DiffService diffService;
	
	public MathServiceImpl(SumService sumService, DiffService diffService) {
		Log.log(sumService, diffService);
		this.sumService = sumService;
		this.diffService = diffService;
	}
	
	@Override
	public int sum(int x, int y) {
		return this.sumService.sum(x, y);
	}

	@Override
	public int diff(int x, int y) {
		return this.diffService.diff(x, y);
	}
}
