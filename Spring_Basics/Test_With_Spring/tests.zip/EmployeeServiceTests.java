package app;


@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
class EmployeeServiceTests {

//	@Test
//	void contextLoads() {
//	}
//	
	@Autowired
	private EmpRepository myserv;
	
	//private Employee emp;
	
	@Test
	void crudTest() {
		
			
	}
	
	@Test
	void chefIndianerTest() {
		
			
	}
	
	//usw. ...
	
}
