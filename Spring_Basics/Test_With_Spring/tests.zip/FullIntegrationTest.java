/* Full Stack Test */

package app;


@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class FullIntegrationTest {
	
//	@Test
//	public void contextLoads() throws Exception {
//		assertTrue(controller != null);
//	}
	
	@Autowired
	private EmployeeController controller;
	
	@LocalServerPort
	private int port;

	@Autowired
	private TestRestTemplate restTemplate;
	
	@Test
	public void testempByiD(){
		Employee e =restTemplate.getForObject("http://localhost:" + port + "/employee/100",	Employee.class);
		assertNotNull(e);
	}
	
	@Test    //(expected=EmployeeNotFoundException.class) nur bei JUnit4
	public void testSomeMethods() {
		//übers Netz kommt keine Exception, stattdessen Statuscode bzw. meine individuelle Rückgabe prüfen
		//		assertThrows(EmployeeNotFoundException.class, () ->
		//		restTemplate.getForObject("http://localhost:" + port + "/employee/-1",	Employee.class));	
				
		
	}

	@Test
	public void testallEmps() {
		
	}
	
	// noch zu Testen:

//	@PostMapping
//	public Employee saveEmp(@RequestBody Employee emp) {
//		if (repo.existsById(emp.getEmployeeId())) {
//			throw new EmployeeExistsException("Employee exists for id: " + emp.getEmployeeId());
//		}
//		return repo.save(emp);
//	}
//
//	@PutMapping("/{id}")
//	public Employee updateEmp(@PathVariable("id") Long id, @RequestBody Employee emp) {
//		if (repo.existsById(id)) {
//			return repo.save(emp);
//		} else {
//			throw new EmployeeNotFoundException("No Employee for id: "+ id);
//		}
//	}
//	
//	@DeleteMapping("/{id}")
//	public void deleteEmp(@PathVariable("id") Long id) {
//		if (repo.existsById(id)) {
//			repo.deleteById(id);  //wirft nur IllegalArgumentException falls ID null
//		} else {
//			throw new EmployeeNotFoundException("No Employee for id: "+ id);
//		}
//	}


	
}
