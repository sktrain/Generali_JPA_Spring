package beans;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import ifaces.Instrument;

@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@Qualifier("karrer")
public class Klavier implements Instrument{
	
	public Klavier(){
		super();
	}
	
	@Override
	public void play() {
		System.out.println("Klavierklänge von " + this);
	}
}

