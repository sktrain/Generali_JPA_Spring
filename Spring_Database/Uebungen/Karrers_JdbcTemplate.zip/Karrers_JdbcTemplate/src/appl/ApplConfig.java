package appl;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import jn.util.DbProperties;
import jn.util.Log;
import jn.util.SimpleDataSource;

@Configuration
public class ApplConfig {
	
	
	//db.properties (shared-Projekt) nutzen
	
	//einfache DriverManagerDataSource oder gepoolte com.mchange.v2.c3p0.ComboPooledDataSource nutzen
	@Bean
	public DataSource dataSource() {
				return null;
	}
	
	//JdbcTemplate bereit stellen
	@Bean 
	public JdbcTemplate template() {
			   return null;
	}
}
