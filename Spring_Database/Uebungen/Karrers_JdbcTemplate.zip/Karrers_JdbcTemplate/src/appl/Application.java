package appl;

import db.util.appl.Db;


public class Application {
	public static void main(String[] args) {
		Db.aroundAppl();

		//JdbcTemplate anhand Context beziehen und nutzen
		//analog Projekt: x1003-JDBC-RowMapper
	}

	
}
