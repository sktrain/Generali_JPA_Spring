/* EmbeddedDatabaseBuilder funktioniert mit H2, aber leider nicht mit Derby.
 *(Doku sagt: sollte funktionieren)
 */

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabase;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;


public class EmbeddedDerby {

	public static void main(String[] args) {

		final DataSource derbyEmbedded = new EmbeddedDatabaseBuilder()
		        .setName("KarrerDB")
		        .setType(EmbeddedDatabaseType.H2)
		        .addScript("classpath:create.sql")
		        .addScript("classpath:populate.sql")
		        .build();
		
		final JdbcTemplate template = new JdbcTemplate(derbyEmbedded);
		final String sql = "select job_title from jobs where job_id = ?";
		final String job = template.query(sql, new Object[] { "AD_PRES" }, rs -> {
			if (!rs.next())
				return null;
			return rs.getString(1);
		});
		System.out.println(job);
		
		((EmbeddedDatabase) derbyEmbedded).shutdown();
		
		

	}

}
