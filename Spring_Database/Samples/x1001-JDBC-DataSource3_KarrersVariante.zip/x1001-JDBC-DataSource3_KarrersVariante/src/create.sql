drop table account;
create table account (
	number integer,
	balance integer,
	primary key (number)
);
