JPA durch Spring gemanaged + deklarative Transaktionsunterstützung

+ Repository-Generierung