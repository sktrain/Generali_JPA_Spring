JPA durch Spring gemanaged + deklarative Transaktionsunterstützung

+ Repository-Generierung mit individuellen Ergänzungen, aber mit Mapping von Employee + Department.

Die direkte Nutzung via generierten Default-Repository von Lazy-Beziehungen ist nicht möglich!

Aber es existiert Abhilfe! (siehe auch https://www.baeldung.com/java-jpa-lazy-collections)