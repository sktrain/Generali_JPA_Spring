package appl;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import db.util.appl.Db;
import domain.Account;
import domain.Job;


public class Application {
	public static void main(String[] args) {
		Db.aroundAppl();

		try (final AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(appl.ApplConfig.class)) {
			final JdbcTemplate template = ctx.getBean(JdbcTemplate.class);
			try {
				demo(template);
			}
			catch (final DataRetrievalFailureException e) {
				System.out.println(e);
			}
			catch (final DataIntegrityViolationException e) {
				System.out.println(e);
			}
			catch (final Exception e) {
				System.out.println(e);
			}
		}
	}

	private static void demo(final JdbcTemplate template) {
		Job j = new Job();
		j.setJobid("Kars_Job");
		j.setJobtitle("Dozent");
		j.setMaxsal(10000);
		j.setMinsal(1000);
		insertJob(template, j);
//		insertAccount(template, new Account(4712));
		final Job job1 = findJob(template, "ST_CLERK");
		System.out.println(job1);
//		account1.setBalance(account1.getBalance() + 5000);
//		updateAccount(template, account1);
		final Job job2 = findJob(template, "AD_PRES");
		System.out.println(job2);
//		account2.setBalance(account2.getBalance() + 6000);
//		updateAccount(template, account2);
		job2.setJobtitle("Praese");
		job2.setMaxsal(100000);
		updateJob(template, job2);
		System.out.println("Jetzt alle: *********************************************************");
		for (final Job job : findAllJobs(template))
			System.out.println(job);
//		deleteAccount(template, account1);
		deleteJob(template, j);
	}

	private static void insertJob(JdbcTemplate template, Job job) {
		final String sql = "insert into jobs values (?, ?, ?, ?)";
		final Object result = template.update(sql, job.getJobid(), job.getJobtitle(),
				                                   job.getMinsal(), job.getMaxsal());
		if ((Integer) result != 1)
			throw new DataRetrievalFailureException(job.toString());
	}

	private static void updateJob(JdbcTemplate template, Job job) {
		final String sql = "update jobs set job_title = ?, min_salary = ?, max_salary = ? where job_id = ?";
		final Object result = template.update(sql, job.getJobtitle(), 
				                                   job.getMinsal(), job.getMaxsal(),job.getJobid());
		if ((Integer) result != 1)
			throw new DataRetrievalFailureException(job.toString());
	}

	private static void deleteJob(JdbcTemplate template, Job job) {
		final String sql = "delete from jobs where job_id = ?";
		final Object result = template.update(sql, job.getJobid());
		if ((Integer) result != 1)
			throw new DataRetrievalFailureException(job.toString());
	}

	private static RowMapper<Job> mapper = (rs, rowNumber) -> {
		final Job a = new Job();
		a.setJobid(rs.getString(1));
		a.setJobtitle(rs.getString(2));
		a.setMaxsal(rs.getInt(4));
		a.setMinsal(rs.getInt(3));
		return a;
	};

	private static Job findJob(JdbcTemplate template, String jobid) {
		final String sql = "select * from jobs where job_id = ?";
		return template.queryForObject(sql, mapper, jobid);
	}

	private static List<Job> findAllJobs(JdbcTemplate template) {
		final String sql = "select * from jobs";
		return template.query(sql, mapper);
	}
}

