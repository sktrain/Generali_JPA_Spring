JPA durch Spring gemanaged + deklarative Transaktionsunterstützung

+ Repository-Generierung mit individuellen Ergänzungen