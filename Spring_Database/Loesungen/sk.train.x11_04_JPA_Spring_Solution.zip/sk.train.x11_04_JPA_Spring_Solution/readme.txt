Umstellung der bisherigen 11_01-Variante auf Spring-Konfiguration:
Simple Variante, bei der lediglich die Komponenten durch Spring erzeugt und verwaltet werden.
Somit: Entity-Manager und EmpService anhand Context beziehen und nutzen.